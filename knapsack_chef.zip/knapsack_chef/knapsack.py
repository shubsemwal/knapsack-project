# knapsack.py

def fractional_knapsack(items, capacity):
    # Add ratio and sort descending
    for item in items:
        item['ratio'] = item['value'] / item['weight']
    
    sorted_items = sorted(items, key=lambda x: x['ratio'], reverse=True)
    
    total_value = 0
    current_weight = 0
    steps = []
    taken_items = []

    for item in sorted_items:
        if current_weight + item['weight'] <= capacity:
            # Take whole item
            current_weight += item['weight']
            total_value += item['value']
            taken_items.append({'name': item['name'], 'fraction': 1.0})
            steps.append(f"Took 100% of {item['name']} (Value: {item['value']}, Weight: {item['weight']})")
        else:
            # Take fraction
            remaining_cap = capacity - current_weight
            fraction = remaining_cap / item['weight']
            fraction_value = item['value'] * fraction
            
            total_value += fraction_value
            current_weight += remaining_cap
            taken_items.append({'name': item['name'], 'fraction': round(fraction, 2)})
            steps.append(f"Took {round(fraction*100, 2)}% of {item['name']} (Value gained: {round(fraction_value, 2)})")
            break # Knapsack is full

    return {
        'total_value': round(total_value, 2),
        'total_weight': current_weight,
        'steps': steps,
        'taken_items': taken_items,
        'type': 'fractional'
    }

def zero_one_knapsack(items, capacity):
    n = len(items)
    # DP Table
    dp = [[0 for _ in range(capacity + 1)] for _ in range(n + 1)]

    for i in range(1, n + 1):
        for w in range(1, capacity + 1):
            item_weight = items[i-1]['weight']
            item_value = items[i-1]['value']
            
            if item_weight <= w:
                dp[i][w] = max(item_value + dp[i-1][w-item_weight], dp[i-1][w])
            else:
                dp[i][w] = dp[i-1][w]

    # Backtrack to find items taken
    w = capacity
    taken_items = []
    for i in range(n, 0, -1):
        if dp[i][w] != dp[i-1][w]:
            taken_items.append({'name': items[i-1]['name'], 'fraction': 1.0})
            w -= items[i-1]['weight']

    steps = [
        "Initialized DP table of size (Items + 1) x (Capacity + 1).",
        "Filled the DP table row by row comparing 'Take Item' vs 'Leave Item'.",
        f"Backtracked from dp[{n}][{capacity}] to find the optimal subset."
    ]

    return {
        'total_value': dp[n][capacity],
        'total_weight': sum(item['weight'] for item in items if item['name'] in [t['name'] for t in taken_items]),
        'steps': steps,
        'taken_items': taken_items[::-1], # Reverse to match original order
        'type': '01'
    }