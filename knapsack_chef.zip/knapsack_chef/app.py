from flask import Flask, render_template, request, jsonify
from knapsack import fractional_knapsack, zero_one_knapsack

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/solve', methods=['POST'])
def solve():
    data = request.json
    items = data.get('items', [])
    capacity = data.get('capacity', 0)
    algo_type = data.get('type', 'fractional')

    if not items or capacity <= 0:
        return jsonify({'error': 'Please add items and set a valid capacity'}), 400

    if algo_type == 'fractional':
        result = fractional_knapsack(items, capacity)
    else:
        result = zero_one_knapsack(items, capacity)

    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True, port=5000)